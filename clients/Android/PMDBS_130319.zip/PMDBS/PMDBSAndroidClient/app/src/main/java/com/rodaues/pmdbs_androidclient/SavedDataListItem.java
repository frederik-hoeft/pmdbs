package com.rodaues.pmdbs_androidclient;


import android.graphics.Bitmap;

public class SavedDataListItem {
    private String host;
    private String addit_text;
    private Bitmap icon;


    public SavedDataListItem(final String host, final String date, final Bitmap icon) {
        this.host = host;
        this.addit_text = date;
        this.icon = icon;

    }

    public String getHost() {
        return host;
    }

    public Bitmap getIcon(){
        return icon;
    }

    public void setHost(final String host) {
        this.host = host;
    }

    public String getAddit_text() {
        return addit_text;
    }

    public void setAddit_text(String date) {
        this.addit_text = date;
    }
}

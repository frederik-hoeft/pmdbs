package com.rodaues.pmdbs_androidclient;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

public class login extends AppCompatActivity {

    EditText et_pw1;
    ImageView greenhook;
    Animation anim_hook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_pw1 = (EditText) findViewById(R.id.et_login_pw1);
        et_pw1.setVisibility(View.VISIBLE);
        greenhook = (ImageView)findViewById(R.id.iv_greenhook);




        et_pw1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String entry = et_pw1.getText().toString();
                if(entry.equals("1234")){
                    hideKB();
                    et_pw1.animate().alpha(0.0f);
                    et_pw1.setVisibility(View.GONE);

                    greenhook.setVisibility(View.VISIBLE);
                    greenhook.animate().alpha(0.0f);
                    greenhook.animate().alpha(1.0f).setDuration(3000);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        greenhook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                greenhook.animate().alpha(0.0f);
                et_pw1.setVisibility(View.VISIBLE);
                startActivity(new Intent(login.this, Main.class));
                finish();
            }
        });

    }

    private void confirmation(){
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void hideKB(){
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}

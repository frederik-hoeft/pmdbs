package com.rodaues.pmdbs_androidclient;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Scanner;

public class BitmapFromURL extends AsyncTask<String, Void, Bitmap>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //start loading screen


        }

        @Override
        protected Bitmap doInBackground(String... string) {

            String rawURL = "http://besticon-demo.her" +
                    "okuapp.com/allicons.json?url="+string[0];
            String resultTXT="NO RESULT!";
            try {
                InputStream in = new URL(rawURL).openConnection().getInputStream();
                Scanner s = new Scanner(in).useDelimiter("\\A");
                resultTXT = s.hasNext() ? s.next() : "";

            } catch (IOException e) {
                e.printStackTrace();
            }


            Bitmap favICON = null;
            if(resultTXT.length()>100){
                String pngURL = resultTXT.split("\"")[9];

                try {
                    InputStream in = new java.net.URL(pngURL).openStream();
                    favICON = BitmapFactory.decodeStream(in);
                } catch (Exception e) {
                    Log.e("Error", e.getMessage());
                    e.printStackTrace();
                }
            }


            return favICON;
        }

        @Override
        protected void onPostExecute(Bitmap b) {
            super.onPostExecute(b);
            //loading screen END !!!!!!!


        }


        private void startLoadingScreen(){
            Class<?> c = null;
            Class noparams[] = {};
            try {
                c = Class.forName("com.rodaues.pmdbs_androidclient.Main");
                Method method = c.getMethod("startLoadingScreen",noparams);
                method.invoke(null,null);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    private void stopLoadingScreen(){
        Class<?> c = null;
        Class noparams[] = {};
        try {
            c = Class.forName("com.rodaues.pmdbs_androidclient.Main");
            Method method = c.getMethod("stopLoadingScreen",noparams);
            method.invoke(null,null);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}

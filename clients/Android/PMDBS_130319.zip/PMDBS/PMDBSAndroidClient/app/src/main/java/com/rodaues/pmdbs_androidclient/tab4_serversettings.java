package com.rodaues.pmdbs_androidclient;

import android.support.v4.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class tab4_serversettings extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab4_serversettings, container, false);
        Context context = rootView.getContext();


        return rootView;
    }


    private void msg(String s){
        Snackbar.make(getActivity().findViewById(android.R.id.content),s, Snackbar.LENGTH_SHORT)
                .setAction("Action", null)
                .setActionTextColor(getResources().getColor(R.color.colorAccent)).show();
    }
}
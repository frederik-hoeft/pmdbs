package com.rodaues.pmdbs_androidclient;
import android.content.Context;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class tab1_addacc extends Fragment implements View.OnClickListener {

    private char[] passwordSpecialCharacters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '_', '-', '$', '%', '&', '/', '(', ')', '=', '?', '{', '[', ']', '}', '\\', '+', '*', '#', ',', '.', '<', '>', '|', '@', '!', '~', ';', ':', '"' };
    private char[] passwordCharacters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
    private Random rng = new Random();

    private Spinner spinner_pw;
    private Button btn_generatepw;
    private CheckBox cb_specialChars;
    private Integer pw_length = 4;
    private EditText et_pw, et_hostname, et_url, et_username, et_email, et_notes;
    private DataBaseHelper dbhelper;
    private FloatingActionButton fab_addaccount;

  /*  private int[] icons = {
            R.drawable.favicon_1_default, R.drawable.favicon_2_google,
            R.drawable.favicon_3_googlemail, R.drawable.favicon_4_googleplus,
            R.drawable.favicon_5_youtube, R.drawable.favicon_6_windows,
            R.drawable.favicon_7_outlook, R.drawable.favicon_8_onedrive,
            R.drawable.favicon_9_dropbox,R.drawable.favicon_10_amazon,
            R.drawable.favicon_11_adobe, R.drawable.favicon_12_apple,
            R.drawable.favicon_13_icloud, R.drawable.favicon_14_facebook,
            R.drawable.favicon_15_messenger, R.drawable.favicon_16_instagram,
            R.drawable.favicon_17_twitter, R.drawable.favicon_18_snapchat,
            R.drawable.favicon_19_skype, R.drawable.favicon_20_whatsapp,
            R.drawable.favicon_21_spotify, R.drawable.favicon_22_paypal,
            R.drawable.favicon_23_linux, R.drawable.favicon_24_github,
            R.drawable.favicon_25_stackoverflow, R.drawable.favicon_26_bbsme,
            R.drawable.favicon_27_autodesk, R.drawable.favicon_28_discord,
            R.drawable.favicon_29_debian, R.drawable.favicon_30_eagames,
            R.drawable.favicon_31_nvidia, R.drawable.favicon_32_user,
            R.drawable.favicon_33_redbubble, R.drawable.favicon_34_rockstar,
            R.drawable.favicon_35_sparkasse, R.drawable.favicon_36_tor,
            R.drawable.favicon_37_uplay

    };*/
    ImageView iv_icon_1, iv_icon_2, iv_icon_3, iv_icon_4, iv_icon_5, iv_icon_6, iv_icon_7, iv_icon_8, iv_icon_9
        , iv_icon_10, iv_icon_11, iv_icon_12, iv_icon_13, iv_icon_14, iv_icon_15, iv_icon_16, iv_icon_17, iv_icon_18,
    iv_icon_19, iv_icon_20, iv_icon_21,iv_icon_22, iv_icon_23, iv_icon_24,iv_icon_25, iv_icon_26, iv_icon_27,iv_icon_28,
    iv_icon_29, iv_icon_30, iv_icon_31,iv_icon_32, iv_icon_33, iv_icon_34,iv_icon_35, iv_icon_36,iv_icon_37, iv_icon_38,
        iv_icon_39,iv_icon_40;
    ImageView iv_accicon;

    View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.tab1_addacc, container, false);
        Context context = rootView.getContext();

        btn_generatepw  =   (Button)    rootView.findViewById(R.id.btn_generate);
        cb_specialChars =   (CheckBox)  rootView.findViewById(R.id.cb_specialchars);
        et_hostname     =   (EditText)  rootView.findViewById(R.id.et_hostname);
        et_url          =   (EditText)  rootView.findViewById(R.id.et_url);
        et_username     =   (EditText)  rootView.findViewById(R.id.et_username);
        et_email        =   (EditText)  rootView.findViewById(R.id.et_email);
        et_notes        =   (EditText)  rootView.findViewById(R.id.et_notes);
        et_pw           =   (EditText)  rootView.findViewById(R.id.et_password);

        //--------------------------------------------------------------IV-ICONS





        //--------------------------------------------------------------IV-ICONS



        //--------------------------------------------------------------SPINNER
        spinner_pw = (Spinner) rootView.findViewById(R.id.spinner_pwlength);
        List<String> list_pwlength = new ArrayList<String>();
        list_pwlength.add("4 CHARS");
        list_pwlength.add("8 CHARS");
        list_pwlength.add("12 CHARS");
        list_pwlength.add("16 CHARS");
        list_pwlength.add("32 CHARS");
        list_pwlength.add("64 CHARS");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,R.layout.spinnerlayout,list_pwlength);
        arrayAdapter.setDropDownViewResource(R.layout.spinnerlayout);
        spinner_pw.setAdapter(arrayAdapter);
        spinner_pw.setSelection(0);
        spinner_pw.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner_pw.setSelection(position);
                switch(position){
                    case 0: pw_length=4;    break;
                    case 1: pw_length=8;    break;
                    case 2: pw_length=12;   break;
                    case 3: pw_length=16;   break;
                    case 4: pw_length=32;   break;
                    case 5: pw_length=64;   break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //--------------------------------------------------------------SPINNER

        fab_addaccount = (FloatingActionButton)rootView.findViewById(R.id.fab_addaccount);
        fab_addaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addaccount();
            }
        });


        dbhelper = new DataBaseHelper(context);
        dbhelper.createDataBase();

        iv_icons();
        generate_pw();


        return rootView;
    }
    @Override
    public void onClick(View view) {
        ImageView iv = (ImageView)view;
        Integer intres = (Integer)iv.getTag();

        iv_accicon.setTag(intres);
        iv_accicon.setImageResource(intres);
    }
    private void addaccount(){

                if(et_hostname.length()>0 && et_pw.length()>0){
                    String hostname     = et_hostname.getText().toString();
                    String url          = et_url.getText().toString();
                    String username     = et_username.getText().toString();
                    String email        = et_email.getText().toString();
                    String password     = et_pw.getText().toString();
                    String notes        = et_notes.getText().toString();

                    long unixTime = System.currentTimeMillis() / 1000L;
                    String date         = String.valueOf(unixTime);

                    ArrayList<String> newData = new ArrayList<>();
                    newData.add(hostname);
                    newData.add(url);
                    newData.add(username);
                    newData.add(password);
                    newData.add(email);
                    newData.add(notes);
                    newData.add(date);

                    Boolean isInserted = dbhelper.data_addrow(newData);

                    if(isInserted){
                        msg("ACCOUNT ADDED");
                    }
                    else{msg("ERROR!");}

                    cb_specialChars.setChecked(true);
                    spinner_pw.setSelection(0);
                    et_hostname.setText("");
                    et_url.setText("");
                    et_username.setText("");
                    et_email.setText("");
                    et_pw.setText("");
                    et_notes.setText("");

                }
                else{
                    msg("MORE INFORMATION IS REQUIRED!");
                }
    }
    private void msg(String s){

        Snackbar.make(getActivity().findViewById(android.R.id.content),s, Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .setActionTextColor(getResources().getColor(R.color.colorAccent)).show();

    }
    private  void generate_pw(){
        btn_generatepw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    et_pw.setText(get_generated_pw(cb_specialChars.isChecked(),pw_length));

                }
                catch(Exception e){
                    msg("ERROR!");
                }

            }
        });
    }


    private String get_generated_pw(boolean specialCharactersEnabled, int pw_length) throws NoSuchPaddingException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, IOException, ClassNotFoundException {
        char[] characterSet;
        StringBuilder randomizedPassword = new StringBuilder();
        if(specialCharactersEnabled){
            characterSet = passwordSpecialCharacters;
        }
        else{
            characterSet = passwordCharacters;
        }
        for (int i = 0; i < pw_length;i++){

            randomizedPassword.append(characterSet[rng.nextInt(characterSet.length-1)]);
        }

        return randomizedPassword.toString();
    }

    private void iv_icons(){
        iv_accicon = (ImageView) rootView.findViewById(R.id.iv_accicon);    iv_accicon.setTag(R.drawable.favicon_32_user);
        iv_icon_1 = (ImageView) rootView.findViewById(R.id.iv_favicon_1);   iv_icon_1.setTag(R.drawable.favicon_1_default);
        iv_icon_2 = (ImageView) rootView.findViewById(R.id.iv_favicon_2);   iv_icon_2.setTag(R.drawable.favicon_2_google);
        iv_icon_3 = (ImageView) rootView.findViewById(R.id.iv_favicon_3);   iv_icon_3.setTag(R.drawable.favicon_3_googlemail);
        iv_icon_4 = (ImageView) rootView.findViewById(R.id.iv_favicon_4);   iv_icon_4.setTag(R.drawable.favicon_4_googleplus);
        iv_icon_5 = (ImageView) rootView.findViewById(R.id.iv_favicon_5);   iv_icon_5.setTag(R.drawable.favicon_5_youtube);
        iv_icon_6 = (ImageView) rootView.findViewById(R.id.iv_favicon_6);   iv_icon_6.setTag(R.drawable.favicon_6_windows);
        iv_icon_7 = (ImageView) rootView.findViewById(R.id.iv_favicon_7);   iv_icon_7.setTag(R.drawable.favicon_7_outlook);
        iv_icon_8 = (ImageView) rootView.findViewById(R.id.iv_favicon_8);   iv_icon_8.setTag(R.drawable.favicon_8_onedrive);
        iv_icon_9 = (ImageView) rootView.findViewById(R.id.iv_favicon_9);   iv_icon_9.setTag(R.drawable.favicon_9_dropbox);
        iv_icon_10 = (ImageView) rootView.findViewById(R.id.iv_favicon_10);   iv_icon_10.setTag(R.drawable.favicon_10_amazon);
        iv_icon_11 = (ImageView) rootView.findViewById(R.id.iv_favicon_11);   iv_icon_11.setTag(R.drawable.favicon_11_adobe);
        iv_icon_12 = (ImageView) rootView.findViewById(R.id.iv_favicon_12);   iv_icon_12.setTag(R.drawable.favicon_12_apple);
        iv_icon_13 = (ImageView) rootView.findViewById(R.id.iv_favicon_13);   iv_icon_13.setTag(R.drawable.favicon_13_icloud);
        iv_icon_14 = (ImageView) rootView.findViewById(R.id.iv_favicon_14);   iv_icon_14.setTag(R.drawable.favicon_14_facebook);
        iv_icon_15 = (ImageView) rootView.findViewById(R.id.iv_favicon_15);   iv_icon_15.setTag(R.drawable.favicon_15_messenger);
        iv_icon_16 = (ImageView) rootView.findViewById(R.id.iv_favicon_16);   iv_icon_16.setTag(R.drawable.favicon_16_instagram);
        iv_icon_17 = (ImageView) rootView.findViewById(R.id.iv_favicon_17);   iv_icon_17.setTag(R.drawable.favicon_17_twitter);
        iv_icon_18 = (ImageView) rootView.findViewById(R.id.iv_favicon_18);   iv_icon_18.setTag(R.drawable.favicon_18_snapchat);
        iv_icon_19 = (ImageView) rootView.findViewById(R.id.iv_favicon_19);   iv_icon_19.setTag(R.drawable.favicon_19_skype);
        iv_icon_20 = (ImageView) rootView.findViewById(R.id.iv_favicon_20);   iv_icon_20.setTag(R.drawable.favicon_20_whatsapp);
        iv_icon_21 = (ImageView) rootView.findViewById(R.id.iv_favicon_21);   iv_icon_21.setTag(R.drawable.favicon_21_spotify);
        iv_icon_22 = (ImageView) rootView.findViewById(R.id.iv_favicon_22);   iv_icon_22.setTag(R.drawable.favicon_22_paypal);
        iv_icon_23 = (ImageView) rootView.findViewById(R.id.iv_favicon_23);   iv_icon_23.setTag(R.drawable.favicon_23_linux);
        iv_icon_24 = (ImageView) rootView.findViewById(R.id.iv_favicon_24);   iv_icon_24.setTag(R.drawable.favicon_24_github);
        iv_icon_25 = (ImageView) rootView.findViewById(R.id.iv_favicon_25);   iv_icon_25.setTag(R.drawable.favicon_25_stackoverflow);
        iv_icon_26 = (ImageView) rootView.findViewById(R.id.iv_favicon_26);   iv_icon_26.setTag(R.drawable.favicon_26_bbsme);
        iv_icon_27 = (ImageView) rootView.findViewById(R.id.iv_favicon_27);   iv_icon_27.setTag(R.drawable.favicon_27_autodesk);
        iv_icon_28 = (ImageView) rootView.findViewById(R.id.iv_favicon_28);   iv_icon_28.setTag(R.drawable.favicon_28_discord);
        iv_icon_29 = (ImageView) rootView.findViewById(R.id.iv_favicon_29);   iv_icon_29.setTag(R.drawable.favicon_29_debian);
        iv_icon_30 = (ImageView) rootView.findViewById(R.id.iv_favicon_30);   iv_icon_30.setTag(R.drawable.favicon_30_eagames);
        iv_icon_31 = (ImageView) rootView.findViewById(R.id.iv_favicon_31);   iv_icon_31.setTag(R.drawable.favicon_31_nvidia);
        iv_icon_32 = (ImageView) rootView.findViewById(R.id.iv_favicon_32);   iv_icon_32.setTag(R.drawable.favicon_32_user);
        iv_icon_33 = (ImageView) rootView.findViewById(R.id.iv_favicon_33);   iv_icon_33.setTag(R.drawable.favicon_33_redbubble);
        iv_icon_34 = (ImageView) rootView.findViewById(R.id.iv_favicon_34);   iv_icon_34.setTag(R.drawable.favicon_34_rockstar);
        iv_icon_35 = (ImageView) rootView.findViewById(R.id.iv_favicon_35);   iv_icon_35.setTag(R.drawable.favicon_35_sparkasse);
        iv_icon_36 = (ImageView) rootView.findViewById(R.id.iv_favicon_36);   iv_icon_36.setTag(R.drawable.favicon_36_tor);
        iv_icon_37 = (ImageView) rootView.findViewById(R.id.iv_favicon_37);   iv_icon_37.setTag(R.drawable.favicon_37_uplay);

        iv_icon_1.setOnClickListener(this); iv_icon_2.setOnClickListener(this);
        iv_icon_3.setOnClickListener(this); iv_icon_4.setOnClickListener(this);
        iv_icon_5.setOnClickListener(this); iv_icon_6.setOnClickListener(this);
        iv_icon_7.setOnClickListener(this); iv_icon_8.setOnClickListener(this);
        iv_icon_9.setOnClickListener(this); iv_icon_10.setOnClickListener(this);
        iv_icon_11.setOnClickListener(this); iv_icon_12.setOnClickListener(this);
        iv_icon_13.setOnClickListener(this); iv_icon_14.setOnClickListener(this);
        iv_icon_15.setOnClickListener(this); iv_icon_16.setOnClickListener(this);
        iv_icon_17.setOnClickListener(this); iv_icon_18.setOnClickListener(this);
        iv_icon_19.setOnClickListener(this); iv_icon_20.setOnClickListener(this);
        iv_icon_21.setOnClickListener(this); iv_icon_22.setOnClickListener(this);
        iv_icon_23.setOnClickListener(this); iv_icon_24.setOnClickListener(this);
        iv_icon_25.setOnClickListener(this); iv_icon_26.setOnClickListener(this);
        iv_icon_27.setOnClickListener(this); iv_icon_28.setOnClickListener(this);
        iv_icon_29.setOnClickListener(this); iv_icon_30.setOnClickListener(this);
        iv_icon_31.setOnClickListener(this); iv_icon_32.setOnClickListener(this);
        iv_icon_33.setOnClickListener(this); iv_icon_34.setOnClickListener(this);
        iv_icon_35.setOnClickListener(this); iv_icon_36.setOnClickListener(this);
        iv_icon_37.setOnClickListener(this);
    }

}

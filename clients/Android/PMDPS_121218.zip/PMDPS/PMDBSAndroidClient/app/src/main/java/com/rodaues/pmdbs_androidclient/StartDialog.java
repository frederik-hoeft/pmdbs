package com.rodaues.pmdbs_androidclient;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class StartDialog extends AppCompatDialogFragment {

    private EditText et_masterpassword1;
    private EditText et_masterpassword2;
    private TextView tv_starttitle;
    private ExampleDialogListener listener;
    private Boolean firstStart = true;

    @Override
    public android.app.Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();

        View view = inflater.inflate(R.layout.dialog_start,null);
        et_masterpassword1=view.findViewById(R.id.et_start_1);
        et_masterpassword2=view.findViewById(R.id.et_start_2);
        tv_starttitle=view.findViewById(R.id.start_title);



        //ABFRAGE OB ERSTER START ODER NICHT!!!!

        //secondStart
        tv_starttitle.setVisibility(View.GONE);
        et_masterpassword2.setVisibility(View.GONE);
        //secondStart


        builder.setView(view)
                .setNegativeButton("DISMISS", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getActivity().finish();

                    }
                })
                .setPositiveButton("CONTINUE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String mp1 = et_masterpassword1.getText().toString();
                        String mp2 = et_masterpassword2.getText().toString();
                        listener.applyTexts(mp1,mp2);
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            listener = (ExampleDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()+"must implement ExampleDialogListener");
        }
    }

    public interface ExampleDialogListener{
        void applyTexts(String mp1, String mp2);
    }

}

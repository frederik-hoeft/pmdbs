package com.rodaues.pmdbs_androidclient;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;

import static java.lang.Integer.parseInt;

public class tab2_savacc extends Fragment {
    private ListView lv_data;
    private LinearLayout layout_data;
    private ImageButton btn_backtolist, btn_dataupdate, btn_datadelete, btn_copypw;
    private Button btn_generatepwdata;
    private Spinner spinner_pwdata;
    private CheckBox cb_specialCharspwdata;
    private Integer pw_lengthdata = 4;
    private Integer item_position;
    private DataBaseHelper dbhelper;
    private TextView tv_datatitle;
    private EditText et_datahostname, et_datausername, et_dataemail, et_datapassword, et_dataurl, et_datanotes;
    private FloatingActionButton fab_refreshlist;

    private char[] passwordSpecialCharacters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '_', '-', '$', '%', '&', '/', '(', ')', '=', '?', '{', '[', ']', '}', '\\', '+', '*', '#', ',', '.', '<', '>', '|', '@', '!', '~', ';', ':', '"' };
    private char[] passwordCharacters = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
    private Random rng = new Random();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab2_savacc, container, false);
        final Context context = rootView.getContext();

        lv_data = (ListView) rootView.findViewById(R.id.lv_data);
        lv_data.setVisibility(View.VISIBLE);

        layout_data = (LinearLayout) rootView.findViewById(R.id.layout_showdata);
        layout_data.setVisibility(View.GONE);

        tv_datatitle    = (TextView) rootView.findViewById(R.id.tv_datatitle);

        et_datahostname = (EditText) rootView.findViewById(R.id.et_datahostname);

        et_dataurl      = (EditText) rootView.findViewById(R.id.et_dataurl);
        et_datausername = (EditText) rootView.findViewById(R.id.et_datausername);
        et_dataemail    = (EditText) rootView.findViewById(R.id.et_dataemail);
        et_datapassword = (EditText) rootView.findViewById(R.id.et_datapassword);
        et_datanotes    = (EditText) rootView.findViewById(R.id.et_datanotes);

        cb_specialCharspwdata =   (CheckBox)  rootView.findViewById(R.id.cb_specialcharspwdata);
        btn_generatepwdata = (Button) rootView.findViewById(R.id.btn_generatepwdata);
        //--------------------------------------------------------------SPINNER
        spinner_pwdata = (Spinner) rootView.findViewById(R.id.spinner_pwlengthpwdata);
        List<String> list_pwlength = new ArrayList<String>();
        list_pwlength.add("4 CHARS");
        list_pwlength.add("8 CHARS");
        list_pwlength.add("12 CHARS");
        list_pwlength.add("16 CHARS");
        list_pwlength.add("32 CHARS");
        list_pwlength.add("64 CHARS");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,R.layout.spinnerlayout,list_pwlength);
        arrayAdapter.setDropDownViewResource(R.layout.spinnerlayout);
        spinner_pwdata.setAdapter(arrayAdapter);
        spinner_pwdata.setSelection(0);
        spinner_pwdata.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner_pwdata.setSelection(position);
                switch(position){
                    case 0: pw_lengthdata=4;    break;
                    case 1: pw_lengthdata=8;    break;
                    case 2: pw_lengthdata=12;   break;
                    case 3: pw_lengthdata=16;   break;
                    case 4: pw_lengthdata=32;   break;
                    case 5: pw_lengthdata=64;   break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //--------------------------------------------------------------SPINNER

        dbhelper = new DataBaseHelper(context);
       // dbhelper.createDataBase();



        et_datahostname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
               String hosttext = et_datahostname.getText().toString();
                tv_datatitle.setText(hosttext);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        lv_data.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                    ArrayList<ArrayList<String>> allData = (ArrayList<ArrayList<String>>) dbhelper.data_getAllData();
                    ArrayList<String> subList = allData.get(position);

                    tv_datatitle.setText(subList.get(1));
                    et_datahostname.setText(subList.get(1));
                    et_dataurl.setText(subList.get(2));
                    et_datausername.setText(subList.get(3));
                    et_datapassword.setText(subList.get(4));
                    et_dataemail.setText(subList.get(5));
                    et_datanotes.setText(subList.get(6));




                item_position = position;


                lv_data.setVisibility(View.GONE);
                fab_refreshlist.setVisibility(View.INVISIBLE);
                layout_data.setVisibility(View.VISIBLE);
            }
        });


        btn_backtolist = (ImageButton) rootView.findViewById(R.id.btn_backtolist);
        btn_backtolist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et_datahostname.length()>0 && et_datapassword.length()>0){
                    updaterow();
                    refresh_listview_data();
                    layout_data.setVisibility(View.GONE);
                    fab_refreshlist.setVisibility(View.VISIBLE);
                    lv_data.setVisibility(View.VISIBLE);
                }
                else msg("MORE INFORMATION IS REQUIRED!");

            }
        });

        fab_refreshlist = (FloatingActionButton) rootView.findViewById(R.id.fab_updatelist);
        fab_refreshlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh_listview_data();

            }
        });

        btn_copypw = (ImageButton) rootView.findViewById(R.id.btn_copypw);
        btn_copypw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(et_datapassword.length()>0){
                    ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("", et_datapassword.getText());
                    clipboard.setPrimaryClip(clip);
                    msg("PASSWORD COPIED TO CLIPBOARD");
                }
            }
        });


        refresh_listview_data();
        generate_pw();

        return rootView;
    }

    private void generate_pw(){
        btn_generatepwdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_datapassword.setText(get_generated_pw(cb_specialCharspwdata.isChecked(),pw_lengthdata));
            }
        });
    }

    private void deleterow(Integer item_position) {

        ArrayList<String> IDs = dbhelper.getIDs();
        String row_id = IDs.get(item_position);

        dbhelper.data_deleterow(row_id);
        msg("DATA DELETED");

        lv_data.setVisibility(View.VISIBLE);
        fab_refreshlist.setVisibility(View.VISIBLE);
        layout_data.setVisibility(View.GONE);
        refresh_listview_data();
    }



    private void updaterow(){
        String hostname     = et_datahostname.getText().toString();
        String url          = et_dataurl.getText().toString();
        String username     = et_datausername.getText().toString();
        String email        = et_dataemail.getText().toString();
        String password     = et_datapassword.getText().toString();
        String notes        = et_datanotes.getText().toString();

        long unixTime = System.currentTimeMillis() / 1000L;
        String date         = String.valueOf(unixTime);

        ArrayList<String> updatedData = new ArrayList<>();
        updatedData.add(hostname);
        updatedData.add(url);
        updatedData.add(username);
        updatedData.add(password);
        updatedData.add(email);
        updatedData.add(notes);
        updatedData.add(date);

        ArrayList<String> IDs = dbhelper.getIDs();
        String row_id = IDs.get(item_position);
        updatedData.add(String.valueOf(row_id));

        String updatedsuccessfully = dbhelper.data_updaterow(updatedData);
        msg(updatedsuccessfully);

    }


    private void refresh_listview_data(){

        ArrayList<ArrayList<String>> allData = (ArrayList<ArrayList<String>>) dbhelper.data_getAllData();


        List<SavedDataList> dataSource = new ArrayList<>();
        for (int i = 0; i < allData.size(); i++) {
            ArrayList<String> subList = allData.get(i);

            Date date = new Date(Integer.valueOf(subList.get(8)) * 1000L);
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT +1"));

            Integer iconPath = dbhelper.icon_getPath(Integer.valueOf(subList.get(0)));


            dataSource.add(new SavedDataList(subList.get(1), sdf.format(date),iconPath));




        }
        lv_data.setAdapter(new SavedDataOverviewListAdapter(getActivity().getApplicationContext(), dataSource));
    }

    private String get_generated_pw(boolean specialCharactersEnabled,int pw_length) {
        char[] characterSet;
        StringBuilder randomizedPassword = new StringBuilder();
        if(specialCharactersEnabled){
            characterSet = passwordSpecialCharacters;
        }
        else{
            characterSet = passwordCharacters;
        }
        for (int i = 0; i < pw_length;i++){

            randomizedPassword.append(characterSet[rng.nextInt(characterSet.length-1)]);
        }

        return randomizedPassword.toString();


    }

    private void msg(String s){
        Snackbar.make(getActivity().findViewById(R.id.main_content),s, Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .setActionTextColor(getResources().getColor(R.color.colorAccent)).show();
    }
}
package com.rodaues.pmdbs_androidclient;


public class SavedDataList {
    private String host;
    private String date;
    private Integer icon;


    public SavedDataList(final String host, final String date, final Integer icon) {
        this.host = host;
        this.date = date;
        this.icon = icon;

    }

    public String getHost() {
        return host;
    }

    public Integer getIcon(){
        return icon;
    }

    public void setHost(final String host) {
        this.host = host;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}

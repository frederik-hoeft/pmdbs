package com.rodaues.pmdbs_androidclient;

import android.app.FragmentManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Random;

public class SavedDataOverviewListAdapter extends ArrayAdapter<SavedDataList> {



    public SavedDataOverviewListAdapter(@NonNull Context context, List<SavedDataList> objects) {
        super(context, 0, objects);

        }
    private int[] icons = {
            R.drawable.favicon_1_default, R.drawable.favicon_2_google,
            R.drawable.favicon_3_googlemail, R.drawable.favicon_4_googleplus,
            R.drawable.favicon_5_youtube, R.drawable.favicon_6_windows,
            R.drawable.favicon_7_outlook, R.drawable.favicon_8_onedrive,
            R.drawable.favicon_9_dropbox,R.drawable.favicon_10_amazon,
            R.drawable.favicon_11_adobe, R.drawable.favicon_12_apple,
            R.drawable.favicon_13_icloud, R.drawable.favicon_14_facebook,
            R.drawable.favicon_15_messenger, R.drawable.favicon_16_instagram,
            R.drawable.favicon_17_twitter, R.drawable.favicon_18_snapchat,
            R.drawable.favicon_19_skype, R.drawable.favicon_20_whatsapp,
            R.drawable.favicon_21_spotify, R.drawable.favicon_22_paypal,
            R.drawable.favicon_23_linux, R.drawable.favicon_24_github,
            R.drawable.favicon_25_stackoverflow, R.drawable.favicon_26_bbsme,
            R.drawable.favicon_27_autodesk, R.drawable.favicon_28_discord,
            R.drawable.favicon_29_debian, R.drawable.favicon_30_eagames,
            R.drawable.favicon_31_nvidia, R.drawable.favicon_32_user,
            R.drawable.favicon_33_redbubble, R.drawable.favicon_34_rockstar,
            R.drawable.favicon_35_sparkasse, R.drawable.favicon_36_tor,
            R.drawable.favicon_37_uplay

    };

    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final SavedDataList currentSavedData = getItem(position);

        View view = convertView;

        if(view == null){
            view = LayoutInflater.from(getContext()).inflate(R.layout.saveddatalist_listitem, parent, false);
        }

        TextView test = (TextView) view.findViewById(R.id.tv_host);
        test.setText(currentSavedData.getHost());
        ((TextView) view.findViewById(R.id.tv_date)).setText(currentSavedData.getDate());


        ImageView iv_item_icon = view.findViewById(R.id.iv_listviewitem_icon);
        iv_item_icon.setImageResource(currentSavedData.getIcon());



         /*TextView tv_date = (TextView) view.findViewById(R.id.tv_date);
        tv_date.setText(currentToList.getDate());*/



       //----------------------------------------------------------------------
       /* view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = currentToList.getHost(); //funktionsfähig!!!
                Toast.makeText(getContext(),s, Toast.LENGTH_SHORT).show();

            }
        });*/
        //----------------------------------------------------------------------

        /* ImageView ivicon = view.findViewById(R.id.iv_listviewitem_icon);

        Random rnd = new Random();
            int rndnumber = rnd.nextInt(26);
           ivicon.setImageResource(icons[rndnumber]);
        */




        return view;
    }

}
